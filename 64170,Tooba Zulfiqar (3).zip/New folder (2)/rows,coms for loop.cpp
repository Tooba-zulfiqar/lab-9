#include<iostream>
using namespace std;
int main()
{
	int rows,colms;
	int sum=0;
//define the size of array
 cout<<"enter the no of rows:";
 cin>>rows;
 cout<<"enter the no colms:";
  cin>>colms;
  
//declare 20 array
 int array[rows][colms];
for(int i=0; i<rows; i++)
	{for(int j=0; j<colms; j++)
	{cout<<"element ["<<i<<"]["<<j<<"]:";
	cin>>array[i][j];}
   }
 cout<<"\n the 2D array is\n";
 for(int i=0; i<rows; i++) 
 	{for(int j=0; j<colms; j++)
	{cout<<array[i][j]<<" ";
sum=sum+array[i][j];
	cout<<"sum of the array is:"<<sum<<endl;}
double avg;
	avg=sum/2;
	cout<<"average of the array is:"<<avg<<endl;
}
	return 0;
}