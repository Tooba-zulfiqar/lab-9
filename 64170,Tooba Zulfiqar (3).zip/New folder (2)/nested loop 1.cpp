#include<iostream>
using namespace std;
int main()
{ int sum;
sum=0;
  int arr[5]={2,3,5,6,7};
  //cout<<"element of the array are:";
for(int i=0; i<5; i++)
  {sum=sum+arr[i];
  cout<<"sum of the array"<<sum;}
  	
	
cout<<endl;	



   return 0;	
}